#include <iostream>
using namespace std;
struct node{
    int key;
    struct node* left, * right;
};
 node* newNode(int item){
     node* temp = new node;
    temp->key = item;
    temp->left = temp->right = NULL;
    return temp;
}
int maxValue( node* node){
     struct node* current = node;
     while (current->right != NULL) {
         current = current->right;
     }
     return(current->key);
}
node* insert(node* node, int key){
    struct node* newNode(int);
    if (node == NULL) return newNode(key);
    if (key < node->key)
        node->left = insert(node->left, key);
    else if (key > node->key)
        node->right = insert(node->right, key);
    return node;
}
int minValue( node* node){
    struct node* current = node;
    while (current->left != NULL){
        current = current->left;
    }
    return(current->key);
}

int main(){
    node* root = NULL;
    root = insert(root, 2);
    int n;
    cout << "How many numbers you want to insert : ";
    cin >> n;
    for (int i = 0; i < n; i++) {
        int n1;
        cout << "Enter the data : ";
        cin >> n1;
        insert(root, n1);
    }
    cout << endl;
    cout << "Maximum value in BST : " << maxValue(root)<<endl;
    cout << "Minimum value in BST : " << minValue(root) << endl;
    return 0;
}
