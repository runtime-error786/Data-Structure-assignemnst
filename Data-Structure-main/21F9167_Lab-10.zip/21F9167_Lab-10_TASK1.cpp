#include <iostream>
using namespace std;
struct node {
    int key;
    struct node* left, * right;
};
node* newNode(int item) {
    struct node* temp = new node;
    temp->key = item;
    temp->left = NULL;
    temp->right = NULL;
    return temp;
}
void inorder(node* root) {
    if (root == NULL) {
        return;
    }
    inorder(root->left);
    cout << root->key << " ";
    inorder(root->right);
    cout << endl;
}
void preorder(node* root) {
    if (root == NULL) {
        return;
    }
    cout << root->key << " ";
    preorder(root->left);
    preorder(root->right);
    cout << endl;
}
void postorder(node* root) {
    if (root == NULL) {
        return;
    }
    postorder(root->left);
    postorder(root->right);
    cout << root->key << " ";
    cout << endl;
}
node* insert(node* node, int key) {
    if (node == NULL)
        return newNode(key);
    if (key < node->key)
        node->left = insert(node->left, key);
    else
        node->right = insert(node->right, key);
    return node;
}
node* search(node* root, int key) {
    if (root == NULL || root->key == key)
        return root;
    if (root->key < key)
        return search(root->right, key);
    return search(root->left, key);
}
int tree_height(node* root) {
    if (!root)
        return 0;
    else {
        int left_height = tree_height(root->left);
        int right_height = tree_height(root->right);
        if (left_height >= right_height) {
            return left_height + 1;
        }
        else
            return right_height + 1;
    }
}
int main() {
    struct node* root = NULL;
    int choice;
    int n;
    do {
        cout << "1- Insert in BST" << endl;
        cout << "2- Inorder in BST" << endl;
        cout << "3- Preorder in BST" << endl;
        cout << "4- Postorder in BST" << endl;
        cout << "5- Search in BST" << endl;
        cout << "6- Height of BST" << endl;
        cin >> choice;
        switch (choice) {
        case 1:
            cout << "Enter the data to insert: ";
            cin >> n;
            root = insert(root, n);
            break;
        case 2:
            cout << "Inorder traversal: ";
            inorder(root);
            break;
        case 3:
            cout << "Preorder traversal: ";
            preorder(root);
            break;
        case 4:
            cout << "Postorder traversal: ";
            postorder(root);
            break;
        case 5:
            cout << "Enter the data to search: ";
            cin >> n;
            search(root, n);
            break;
        case 6:
            int height = tree_height(root);
            cout << "height is : " << height<<endl;
            break;
        }
    } while (choice != 7);
    return 0;
}

