#include<iostream>
using namespace std;
class node {
public:
    int data;
    class node* next;
    class node* prev;
};
class dqueue : public node {
    node* head, * tail;
    int top1, top2;
public:
    dqueue() {
        top1 = 0;
        top2 = 0;
        head = NULL;
        tail = NULL;
    }
    void push_at_front(int x) {
        node* temp;
        top1++;
        temp = new node;
        temp->data = x;
        temp->next = head;
        temp->prev = NULL;
        head->prev = temp;
        head = temp;
    }
    void push_at_last(int x) {
        node* temp;
        top2++;
        temp = new node;
        temp->data = x;
        temp->next = NULL;
        temp->prev = tail;
        tail->next = temp;
        tail = temp;
    }
    void push(int x) {
        node* temp;
        if (top1 + top2 >= 5) {
            cout << "dqueue overflow" << endl;
            return;
        }
        if (top1 + top2 == 0) {
            head = new node;
            head->data = x;
            head->next = NULL;
            head->prev = NULL;
            tail = head;
            top1++;
        }
        else {
            int choicee = 0;
            cout << "1- Insert at first" << endl;
            cout << "2- Insert at last" << endl;
            cin >> choicee;
            if (choicee == 1) {
                push_at_front(x);
            }
            else if (choicee == 2) {
                push_at_last(x);
            }
        }
    }
    void pop_at_front() {
        if (top1 + top2 <= 0) {
            cout << "Queue is empty" << endl;
            return;
        }
        else {
            head = head->next;
            cout << "The element deleted from front is : " << head->prev->data << endl;
            head->prev = NULL;
            top1--;
        }
    }
    void pop_at_last() {
        if (top1 + top2 <= 0) {
            cout << "Queue is empty" << endl;
            return;
        }
        else {
            top2--;
            tail = tail->prev;
            cout << "The element deleted from last is : " << tail->next->data << endl;
            tail->next = NULL;
        }
    }
    void display() {
        node* temp;
        if (top1 + top2 <= 0) {
            cout << "queue is empty" << endl;
            return;
        }
        else {
            temp = head;
            cout << "Queue is : ";
            while (temp != NULL) {
                cout << temp->data << " ";
                temp = temp->next;
            }
        }
        cout << endl;
    }
    void isempty() {
        if (top1 + top2 <= 0) {
            cout << "Queue is empty" << endl;
            return;
        }
    }
};
int main() {
    dqueue d1;
    int ch;
    while (1) {
        cout << "1- Insert" << endl;
        cout << "2- Insert at front" << endl;
        cout << "3- Insert at last" << endl;
        cout << "4- Delete at front" << endl;
        cout << "5- Delete at last" << endl;
        cout << "6- Display" << endl;
        cout << "7- Check Empty" << endl;
        cout << "8- EXIT" << endl;
        cout << "Enter Your Choice : ";
        cin >> ch;
        switch (ch) {
        case 1:
            cout << "Enter the Element: ";
            cin >> ch;
            d1.push(ch);
            break;
        case 2:
            cout << "Enter the Element: ";
            cin >> ch;
            d1.push_at_front(ch);
            break;
        case 3:
            cout << "Enter the Element: ";
            cin >> ch;
            d1.push_at_last(ch);
            break;
        case 4:
            d1.pop_at_front();
            break;
        case 5:
            d1.pop_at_last();
            break;
        case 6:
            d1.display();
            break;
        case 7:
            d1.isempty();
            break;
        case 8:
            exit(1);
        }
    }
    return 0;
}