#include<iostream>
using namespace std;

void number(int arr[][10]){
	int count;
	for (int i = 0; i < 10; i++){
		count = 0;
		cout << i << " : ";
		for (int j = 0; j < 10; j++){
			if (arr[i][j] == 1){
				cout << "{" << i << " , " << j << "} , ";
				count++;
			}
		}
		cout << endl << "Total edges with " << i << " are " << count << endl;
	}
}
void insertion(int arr[][10], int x, int y) {
	arr[x][y] = 1;
	if (x != y)
		arr[y][x] = 1;
}

int main(){
	int arr[10][10];
	for (int i = 0; i < 10; i++){
		for (int j = 0; j < 10; j++){
			arr[i][j] = 0;
		}
	}
	insertion(arr, 0, 2);
	insertion(arr, 0, 4);
	insertion(arr, 0, 5);
	insertion(arr, 1, 4);
	insertion(arr, 1, 6);
	insertion(arr, 1, 9);
	insertion(arr, 2, 7);
	insertion(arr, 1, 6);
	insertion(arr, 2, 4);
	insertion(arr, 3, 5);
	insertion(arr, 3, 1);
	insertion(arr, 5, 5);
	insertion(arr, 9, 2);
	insertion(arr, 7, 8);
	insertion(arr, 7, 9);
	for (int i = 0; i < 8; i++){
		for (int j = 0; j < 10; j++){
			cout << arr[i][j] << " ";
		}
		cout << endl;
	}
	number(arr);
	return 0;
}
