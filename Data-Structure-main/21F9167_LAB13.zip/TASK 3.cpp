#include <iostream>
using namespace std;

int main(){
	int** arr;
	int* count;
	int vertices, m;
	cout << "Input number of vertices: ";
	cin >> vertices;
	arr = new int* [vertices];
	count = new int[vertices];
	int i = 0;
	while ( i < vertices){
		arr[i] = new int[vertices];
		count[i] = 0;
		i++;
	}
	i = 0;
	while ( i < vertices){
		for (int j = 0; j < vertices; j++){
			arr[i][j] = 0;
		}
		i++;
	}
	cout << "Enter number of edges: ";
	cin >> m;
	int x, y;
	for (int k = 0; k < m; k++){
		cout << "Enter 1st vertice: ";
		cin >> x;
		cout << "Enter 2nd vertice: ";
		cin >> y;
		arr[x][y] = 1;
		arr[y][x] = 1;
	}
	cout << "Adjacency Matrix: " << endl;
	for (int i = 0; i < vertices; i++){
		for (int j = 0; j < vertices; j++){
			if (arr[i][j] == 1){
				count[i]++;
			}
			cout << arr[i][j] << " ";
		}
		cout << endl;
	}
	int** list;
	list = new int* [vertices];
	 i = 0;
	while ( i < vertices){
		list[i] = new int[count[i]];
		i++;
	}
	for (int i = 0; i < vertices; i++){
		for (int j = 0; j < count[i]; j++){
			for (int k = 0; k < vertices; k++){
				if (arr[i][k] == 1){
					list[i][j] = k;
					j++;
				}
			}
		}
	}
	cout << "adjacency list: " << endl;
	for (int i = 0; i < vertices; i++){
		cout << "for " << i << " : ";
		for (int j = 0; j < count[i]; j++){
			cout << list[i][j];
		}
		cout << endl;
	}
}
