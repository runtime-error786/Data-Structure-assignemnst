#include<iostream>
using namespace std;
class Hashing {
private:
	int* arr;
	int size;
public:
	Hashing() {
		size = 10;
		arr = new int[size];
		for (int i = 0; i < size; i++) {
			arr[i] = 0;
		}
	}
	void insert(int value) {
		int copy = value;
		if (!NotFull()) {
			cout << "Hash Table is Filled\n";
			return;
		}
		else if (NotFull()) {
			int index = getindex(value);
			while (true) {
				if (index == size) {
					index = wrapround();
					continue;
				}
				else if (arr[index] == 0) {
					arr[index] = value;
					break;
				}
				index++;
			}
		}
	}
	int wrapround() {
		return 0;
	}
	int getindex(int key) {
		return key % size;
	}
	bool NotFull() {
		int count = 0;
		for (int i = 0; i < size; i++) {
			if (arr[i] == 0) {
				count++;
			}
		}
		if (count >= 1) {
			return true;
		}
		else {
			return false;
		}
	}
	bool search(int value) {
		int index = getindex(value);
		while (true) {
			if (index == size) {
				index = wrapround();
				continue;
			}
			else if (arr[index] == value) {
				cout << "Element Found successfully\n";
				return true;
				break;
			}
			index++;
		}
		return false;
	}
	bool delete_element(int value) {
		int index = getindex(value);
		while (true) {
			if (index == size) {
				index = wrapround();
				continue;
			}
			else if (arr[index] == value) {
				arr[index] = 0;
				cout << "Element Deleted successfully\n";
				return true;
				break;
			}
			index++;
		}
		return false;
	}
	void display() {
		cout << "Hash Table is: ";
		for (int i = 0; i < size; i++) {
			cout << arr[i] << " ";
		}
		cout << endl;
	}
};
int main() {
	Hashing obj;
	int n;
	for (int i = 0; i < 10; i++) {
		cin >> n;
		obj.insert(n);
	}
	obj.display();
	obj.search(22);
	obj.delete_element(34);
	obj.display();
	system("pause");
	return 0;
}
