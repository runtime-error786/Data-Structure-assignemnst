#include<iostream>
using namespace std;
class Hashing {
private:
	int* arr;
	int size;
public:
	Hashing() {
		size = 10;
		arr = new int[size];
		for (int i = 0; i < size; i++) {
			arr[i] = 0;
		}
	}
	void insert(int value) {
		int copy = value;
		if (!NotFull()) {
			cout << "Hash Table is Filled\n";
			return;
		}
		else if (NotFull()) {
			int index = getindex(value);
			if (arr[index] == 0) {
				arr[index] = value;
			}
			else if (arr[index] != 0) {
				findfreelocation(index, 0, value);
			}
		}
	}
	void findfreelocation(int index, int i, int value) {
		int getindex = ((index + (i * i)) % size);
		if (getindex == size) {
			return;
		}
		if (arr[getindex] == 0) {
			arr[getindex] = value;
			return;
		}
		else {
			findfreelocation(index, ++i, value);
		}
	}
	int getindex(int key) {
		return ((key) % size);
	}
	bool NotFull() {
		int count = 0;
		for (int i = 0; i < size; i++) {
			if (arr[i] == 0) {
				count++;
			}
		}
		if (count >= 1) {
			return true;
		}
		else
		{
			return false;
		}
	}
	bool search(int value) {
		int index = getindex(value);
		int s = 0;
		if (arr[index] == value) {
			cout << "Element Founded Successfully at index " << index + 1 << "\n";
		}
		else if (arr[index] != value) {
			findsearch(index, 0, value, s);
			if (s == 1) {
				return true;
			}
			else {
				return false;
			}
		}
	}
	void findsearch(int index, int i, int value, int& s) {
		int getindex = ((index + (i * i)) % size);
		if (getindex == size) {
			return;
		}
		if (arr[getindex] == value) {
			cout << "Element Founded Successfully at index " << getindex + 1 << "\n";
			s = 1;
			return;
		}
		else {
			findsearch(index, ++i, value, s);
		}
	}
	bool delete_element(int value) {
		int index = getindex(value);
		if (arr[index] == value) {
			arr[index] = 0;
			cout << "Element Founded Successfully at index " << index + 1 << " and deleted\n";
			return true;
		}
		else if (arr[index] != value) {
			findndelete(index, 0, value);
		}
		return true;
	}
	void findndelete(int index, int i, int value) {
		int getindex = ((index + (i * i)) % size);
		if (arr[getindex] == value) {
			arr[getindex] = 0;
			cout << "Element Founded Successfully at index " << getindex + 1 << "\n";
			return;
		}
		else {
			findndelete(index, ++i, value);
		}
	}
	void display() {
		cout << "Hash Table is: ";
		for (int i = 0; i < size; i++) {
			cout << arr[i] << " ";
		}
		cout << endl;
	}
};
int main() {
	Hashing obj;
	int size;
	for (int i = 0; i < 10; i++) {
		int n;
		cin >> n;
		obj.insert(n);
	}
	obj.display();
	cout << "Enter number to search: ";
	cin >> size;
	obj.search(size);
	cout << "Enter number to delete: ";
	cin >> size;
	obj.delete_element(size);
	obj.display();
	system("pause");
	return 0;
}
