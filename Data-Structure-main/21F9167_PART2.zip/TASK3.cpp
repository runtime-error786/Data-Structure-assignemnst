#include <iostream>
using namespace std;
struct node {
    int key;
    struct node* left, * right;
};
node* newNode(int item) {
    struct node* temp = new node;
    temp->key = item;
    temp->left = NULL;
    temp->right = NULL;
    return temp;
}
void inorder(node* root) {
    if (root == NULL) {
        return;
    }
    inorder(root->left);
    cout << root->key << " ";
    inorder(root->right);
    cout << endl;
}
node* insert(node* node, int key) {
    if (node == NULL)
        return newNode(key);
    if (key < node->key)
        node->left = insert(node->left, key);
    else
        node->right = insert(node->right, key);
    return node;
}
node* deleteNode(struct node* root, int key) {
    if (root == NULL) return root;
    if (key < root->key)
        root->left = deleteNode(root->left, key);
    else if (key > root->key)
        root->right = deleteNode(root->right, key);
    else {
        if (root->left == NULL) {
            struct node* temp = root->right;
            free(root);
            return temp;
        }
        else if (root->right == NULL) {
            struct node* temp = root->left;
            free(root);
            return temp;
        }
        struct node* current = root->right;
        while (current && current->left != NULL)
        current = current->left;
        struct node* temp = current;
        root->key = temp->key;
        root->right = deleteNode(root->right, temp->key);
    }
    return root;
}

int main() {
    struct node* root = NULL;
    int choice;
    int n;
    do {
        cout << "1- Insert in BST" << endl;
        cout << "2- Inorder in BST" << endl;
        cout << "3- Deletion in BST" << endl;
        cin >> choice;
        switch (choice) {
        case 1:
            cout << "Enter the data to insert: ";
            cin >> n;
            root = insert(root, n);
            break;
        case 2:
            cout << "Inorder traversal: ";
            inorder(root);
            break;
        case 3:
            cout << "Enter the data to delete: ";
            cin >> n;
            root = deleteNode(root, n);
        case 4:
            break;
        }
    } while (choice != 4);
    return 0;
}
