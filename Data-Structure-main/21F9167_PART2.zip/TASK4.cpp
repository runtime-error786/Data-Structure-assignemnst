#include<iostream>
using namespace std;
class Node{
public:
	int data;
	Node* left;
	Node* right;
	Node()
	{
		left = right = NULL;
	}
};
class binarySearchTree{
	Node* root;
	void insert(int data, Node*& ptr){
		if (ptr == NULL) {
			ptr = new Node;
			ptr->data = data;
			ptr->left = NULL;
			ptr->right = NULL;

		}
		else if (ptr->data > data){
			insert(data, ptr->left);
		}
		else if (ptr->data < data){
			insert(data, ptr->right);
		}
	}
	int BST(Node*& ptr){
		if (ptr){
			if (ptr->left){
				if (ptr->right){
					if (ptr->left->data > ptr->right->data){
						cout << "Not BST";
						return 0;
					}
				}
				else{
					cout << "Not BST";
					return 0;
				}
			}
			else{
				cout << "Not BST";
				return 0;
			}
		}
		else{
			return 0;
		}
	}
public:
	binarySearchTree(){
		root = NULL;
	}
	void Insert(int data){
		insert(data, root);
	}
	void isBST(){
		BST(root);
		cout << endl;
	}
};
int main(){
	binarySearchTree obj;
	int size = 0, data, choice = -1;
	cout << "Enter Size : ";
	cin >> size;
	int* ptr = new int[size];
	for (int i = 0; i < size; i++){
		cout << "Enter Value #" << i + 1 << " : ";
		cin >> ptr[i];
	}
	for (int i = 0; i < size; i++){
		obj.Insert(ptr[i]);
	}
	obj.isBST();
	system("pause");
	return 0;
}
