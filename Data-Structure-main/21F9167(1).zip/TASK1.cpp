#include<iostream>
using namespace std;

void DFS(int& i, int* visited, int a[][13], int nodes, int path, bool& check) {

	if (check == 0) {
		if (visited[i] == 0) {
			cout << i << " ";
			visited[i] = 1;
			if (i == path) {
				check = 1;
				return;
			}
			else if (i != path) {
				for (int j = 0; j <= path; j++) {
					if (a[i][j] == 1 && visited[j] == 0) {

						DFS(j, visited, a, nodes, path, check);
					}
				}
			}
		}
	}
}

int main() {
	bool check = 0;
	// DFS 

	int i = 0;
	int visited[13] = { 0,0,0,0,0,0,0,0,0,0,0,0,0 };
	int a[13][13] = {
	{ 0,1,1,0,0,0,0,0,0,0,0,0,0 }, //0
	{ 1,0,0,1,1,0,0,0,0,0,0,0,0 }, //1
	{ 1,0,0,0,0,1,0,0,0,0,0,0,0 }, //2
	{ 0,1,0,0,0,0,1,1,0,0,0,0,0 }, //3
	{ 0,1,0,0,0,0,0,0,1,0,0,0,0 }, //4
	{ 0,0,1,0,0,0,0,0,0,1,0,0,0 }, //5
	{ 0,0,0,1,0,0,0,0,0,0,1,1,0 }, //6
	{ 0,0,0,1,0,0,0,0,1,0,0,0,0 }, //7
	{ 0,0,0,1,0,0,0,0,0,1,0,0,1 }, //8
	{ 0,0,0,0,0,1,0,0,0,0,0,0,0 }, //9
	{ 0,0,0,0,0,0,1,0,0,0,0,0,0 }, //10
	{ 0,0,0,0,0,0,1,0,0,0,0,0,0 }, //11
	{ 0,0,0,0,0,0,0,0,1,0,0,0,0 }, //12
	};

	DFS(i, visited, a, 13, 6, check);


	cout << endl;
	system("pause");
	return 0;
}
