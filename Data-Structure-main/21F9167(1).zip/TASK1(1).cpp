#include<iostream>
using namespace std;

class Queue {
	int size;
	int front, rear;
	int* arr;
public:
	//Constructor for Queue class
	Queue(int size) {
		this->size = size;
		front = rear = 0;
		arr = new int[size];
	}

	// Function to check if Queue is Empty or Not
	bool isEmpty() {
		if (front == rear) {
			return 1;
		}
		return 0;
	}

	// Function to check if Queue is Full or Not
	bool isFull() {
		if (rear == size - 1) {
			return 1;
		}
		return 0;
	}

	// Funtion to insert elements in Queue
	void enqueue(int val) {
		if (isFull()) {
			cout << "Queue is full!" << endl;
		}
		else {
			rear++;
			arr[rear] = val;
		}
	}

	// Funtion to delete(pop) elements from Queue
	int dequeue() {
		if (isEmpty()) {
			cout << "Queue is Empty!" << endl;
			return -1;
		}
		else {
			front++;
			int val = arr[front];
			return val;
		}
	}

	// To display elements of the Queue
	void display() {
		if (isEmpty()) {
			cout << "Queue is empty!" << endl;
		}
		else {
			cout << "The elements of stack are as follows: - " << endl;
			for (int i = front; i <= rear; i++) {
				if (i == -1) {
					continue;
				}
				cout << arr[i] << " ";
			}
			cout << endl;
		}
	}
};

int main() {
	bool chk = 0;

	// Initializing Queue (Array Implementation)
	Queue q(400);


	// BFS 
	int node = 0;
	int i = 0;
	int visited[13] = { 0,0,0,0,0,0,0,0,0,0,0,0,0 };
	int a[13][13] = {
	{ 0,1,1,0,0,0,0,0,0,0,0,0,0 }, //0
	{ 1,0,0,1,1,0,0,0,0,0,0,0,0 }, //1
	{ 1,0,0,0,0,1,0,0,0,0,0,0,0 }, //2
	{ 0,1,0,0,0,0,1,1,0,0,0,0,0 }, //3
	{ 0,1,0,0,0,0,0,0,1,0,0,0,0 }, //4
	{ 0,0,1,0,0,0,0,0,0,1,0,0,0 }, //5
	{ 0,0,0,1,0,0,0,0,0,0,1,1,0 }, //6
	{ 0,0,0,1,0,0,0,0,1,0,0,0,0 }, //7
	{ 0,0,0,1,0,0,0,0,0,1,0,0,1 }, //8
	{ 0,0,0,0,0,1,0,0,0,0,0,0,0 }, //9
	{ 0,0,0,0,0,0,1,0,0,0,0,0,0 }, //10
	{ 0,0,0,0,0,0,1,0,0,0,0,0,0 }, //11
	{ 0,0,0,0,0,0,0,0,1,0,0,0,0 }, //12
	};
	cout << i << " ";
	visited[i] = 1;
	q.enqueue(i); // Enqueue i for exploration
	while (!q.isEmpty()) {
		int node = q.dequeue();
		for (int j = 0; j < 13; j++) {
			if (chk == 1) {
				break;
			}
			if (a[node][j] == 1 && visited[j] == 0) {
				cout << j << " ";
				visited[j] = 1;
				q.enqueue(j);
				if (j == 6) {
					chk = 1;
				}

			}

		}
	}


	cout << endl;
	system("pause");
	return 0;
}
