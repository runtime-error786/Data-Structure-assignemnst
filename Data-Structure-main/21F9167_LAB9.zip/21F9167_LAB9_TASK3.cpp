#include<iostream>
using namespace std;
#define SIZE 10
class Dequeue{
    int* arr;
    int front, rear;
public:
    Dequeue(){
        //Create the array
        arr = new int[SIZE];
        front = -1;
        rear = -1;
    }
    // Operations on Deque
    void  push_front(int key){
        if (full()){
            cout << "OVERFLOW\n";
        }
        else{
            //If queue is empty
            if (front == -1)
                front = rear = 0;
            //If front points to the first position element 
            else if (front == 0)
                front = SIZE - 1;
            else
                --front;
            arr[front] = key;
        }
    }
    void  push_back(int key) {
        if (full()){
            cout << "OVERFLOW\n";
        }
        else{
            //If queue is empty
            if (front == -1)
                front = rear = 0;
            //If rear points to the last element
            else if (rear == SIZE - 1)
                rear = 0;
            else
                ++rear;
            arr[rear] = key;
        }
    }
    void  pop_front(){
        if (empty()){
            cout << "UNDERFLOW\n";
        }
        else{
            //If only one element is present
            if (front == rear)
                front = rear = -1;
            //If front points to the last element 
            else if (front == SIZE - 1)
                front = 0;
            else
                ++front;
        }
    }
    void  pop_back() {
        if (empty()){
            cout << "UNDERFLOW\n";
        }
        else{
            //If only one element is present
            if (front == rear)
                front = rear = -1;
            //If rear points to the first position element 
            else if (rear == 0)
                rear = SIZE - 1;
            else
                --rear;
        }
    }
    int  get_front() {
        if (empty()){
            cout << "f=" << front << endl;
            cout << "UNDERFLOW\n";
            return -1;
        }
        else{
            return arr[front];
        }
    }
    int  get_back() {
        if (empty()){
            cout << "UNDERFLOW\n";
            return -1;
        }
        else{
            return arr[rear];
        }
    }
    bool  full() {
        if ((front == 0 && rear == SIZE - 1) || (front == rear + 1)) {
            cout << "Is full" << endl;
            return true;
        }
        else {
            cout << "Not Full" << endl;
            return false;
        }
    }
    bool  empty() {
        if (front == -1) {
            cout << "Is empty" << endl;
            return true;
        }
        else {
            cout << "Is not empty" << endl;
            return false;
        }
    }
    void display() {
        int i;
        if (front == -1 && rear == -1) {
            cout << "Queue is empty" << endl;
        }
        else {
            cout << "Queue is : ";
            for (i = front; i <= rear; i++) {
                cout << arr[i] << " ";
            }
        }
        cout << endl;
    }
};

int main() {
    Dequeue queue;
    int choice, n, data, p;
    int i = 0;
    int ffront = 0;
    int bback = 0;
    cout << "Enter Your Choice:-" << endl;
    do {
        cout << "1- Insert the Data in front" << endl;
        cout << "2- Insert the Data in back" << endl;
        cout << "3- Pop front" << endl;
        cout << "4- Pop back" << endl;
        cout << "5- Get front" << endl;
        cout << "6- Get back" << endl;
        cout << "7- Check Full" << endl;
        cout << "8- Check Empty" << endl;
        cout << "9- Display" << endl;
        cout << "10- Exit" << endl;
        cin >> choice;
        switch (choice) {
        case 1:
            cout << "Enter Data : ";
            cin >> data;
            queue.push_front(data);
            break;
        case 2:
            cout << "Enter Data : ";
            cin >> data;
            queue.push_back(data);
            break;
        case 3:
            queue.pop_front();
            break;
        case 4:
            queue.pop_back();
            break;
        case 5:
            ffront=queue.get_front();
            cout << "Front of queue is : " << ffront << endl;
            break;
        case 6:
            bback=queue.get_back();
            cout << "Back of queue is : " << bback << endl;
            break;
        case 7:
            queue.full();
            break;
        case 8:
            queue.empty();
            break;
        case 9:
            queue.display();
            break;
        case 10:
            break;
        default:
            cout << "Invalid Choice" << endl;
        }
    } while (choice != 10);
    return 0;
}

