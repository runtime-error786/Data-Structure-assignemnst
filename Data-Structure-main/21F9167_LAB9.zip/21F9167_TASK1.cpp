#include<iostream>
#define SIZE 10
using namespace std;

class PriortiyQueue {
private:
	int Q[SIZE], Pr[SIZE];
	int rear, front;
public:
	PriortiyQueue() {
		rear = -1;
		front = -1;
	}
	void enqueue(int data, int p) {
		//Enqueue function to insert data and its priority in the queue
		int i;
		if ((front == 0) && (rear == SIZE - 1)) //Check if Queue is full. 
			//If  front is 0 and rear is size -1 it indicates queue is full
			cout << "Queue is full";
		else {
			if (front == -1) { //if queue is empty or first index
				front = 0;
				rear = 0;
				Q[rear] = data;
				Pr[rear] = p;
			}
			else if (rear == SIZE - 1)//if there there is already atleast some elemets in Queue
			{
				for (int i = front; i <= rear; i++) {
					Q[i - front] = Q[i];
					Pr[i - front] = Pr[i];
					rear = rear - front;
					front = 0;
					for (i = rear; i > front; i--) {
						if (p > Pr[i]) {
							Q[i + 1] = Q[i];
							Pr[i + 1] = Pr[i];
						}
						else
							break;
						Q[i + 1] = data;
						Pr[i + 1] = p;
						rear++;
					}
				}
			}
			else {
				for (i = rear; i >= front; i--) {
					if (p > Pr[i]) {
						Q[i + 1] = Q[i];
						Pr[i + 1] = Pr[i];
					}
					else
						break;
				}
				Q[i + 1] = data;
				Pr[i + 1] = p;
				rear++;
			}
		}

	}
	void print() { //print the data of Queue
		int i;
		if (front == -1 && rear == -1) {
			cout << "Queue is empty" << endl;
		}
		else {
			for (i = front; i <= rear; i++) {
				cout << "Element is : " << Q[i] << " Priority is : " << Pr[i] << endl;
			}
		}
	}
	int dequeue() { //remove the data from front
		if (front == -1) {
			cout << "Queue is Empty"<<endl;
		}
		else {
			cout << "deleted Element = " << Q[front] << endl;
			cout << "Its Priority = " << Pr[front] << endl;
			if (front == rear) {
				front = -1;
				rear = -1;
			}
			else
				front++;
		}
		return Q[front];
	}
};
int main() {
	PriortiyQueue queue;
	int choice, n, data, p;
	int i = 0;
	cout << "Enter Your Choice:-" << endl;
	do {
		cout << "1- Insert the Data in Queue" << endl;
		cout << "2- show the Data in Queue" << endl;
		cout << "3- Delete the data from the Queue" << endl;
		cout << "4- Exit" << endl;
		cin >> choice;
		switch (choice) {
		case 1:
			cout << "Enter the number of data you want to insert : " << endl;
			cin >> n;
			while (SIZE < n) {
				cout << "The total number of data you want to enter cannot be greater than 10" << endl;
				cin >> n;
			}
			while (i < n) {
				cout << "Enter Data : ";
				cin >> data;
				cout << "Enter Priority : ";
				cin >> p;
				queue.enqueue(data, p);
				i++;
			}
			break;
		case 2:
			queue.print();
			break;
		case 3:
			queue.dequeue();
			break;
		case 4:
			break;
		default:
			cout << "Invalid Choice" << endl;
		}
	} while (choice != 4);
	return 0;
}