#include <iostream>
using namespace std;
#define SIZE 5   //defining queue size as 5
class Queue {
private:
	int A[SIZE];   //making array of size 5
	int front = -1;   //front is -1 because we have to enter in queue at index 0 at first
	int rear = -1;   //rear is -1 because we have to enter in queue at index 0 at first
public:
	bool isempty() {  //to check if queue is empty or not
		if (front == -1 && rear == -1)   //if this is the case then true because queue is empty
			return true;
		else
			return false;   //else not empty so return false
	}
	void enqueue(int value) {  //adding value in queue
		if (rear == SIZE - 1)
			cout << "Queue is full" << endl;   //if the rear of queue is size-1 then it means queue is full
		else {
			if (front == -1)
				front = 0;
			rear++;  //else rear++
			A[rear] = value;   //add value in that index
		}
	}
	void dequeue() {   //to pop out of queue
		if (isempty())   //if queue is empty nothing will be popped out
			cout << "Queue is empty\n";
		else
			if (front == rear)
				front = rear = -1;
			else
				front++;
	}
	void displayQueue() {
		if (isempty())   //if queue is empty nothing will be displayed
			cout << "Queue is empty\n";
		else {
			for (int i = front; i <= rear; i++)  //else run for loop till all the data in the queue is printed
				cout << A[i] << " ";
			cout << endl;
		}
	}
};

int main() {
	Queue queue;
	//adding elements in queue and displaying them step by step
	cout << "Insert elements inside queue" << endl;
	queue.enqueue(3);
	queue.displayQueue();
	queue.enqueue(4);
	queue.displayQueue();
	queue.enqueue(5);
	queue.displayQueue();
	queue.enqueue(6);
	queue.displayQueue();
	queue.enqueue(7);
	queue.displayQueue();
	queue.enqueue(8);
	//removing elements from queue and displaying them step by step
	cout << "Remove elements from the queue" << endl;
	queue.dequeue();
	queue.displayQueue();
	queue.dequeue();
	queue.displayQueue();
	queue.dequeue();
	queue.displayQueue();
	queue.dequeue();
	queue.displayQueue();
	queue.dequeue();
	return 0;
}
