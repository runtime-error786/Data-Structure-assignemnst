#include <iostream>
using namespace std;
class node {
private:
    int data;
    node* next;
    node* front = NULL;
    node* rear = NULL;
    node* temp;
public:
    void enqueue(int n1) {
        //the function enqueue() inserts an element into the queue.
        if (rear == NULL) {       //If rear is NULL,then the queue is empty and a single element is inserted. 
            rear = new node;  //dynamically creating new node
            rear->next = NULL;  //if the next node is null then
            rear->data = n1;   // the data in rear is n1
            front = rear;  //front will then be same as rear
        }
        else {    //Otherwise, a node is inserted after rear with the required element and then that node is set to rear. 
            temp = new node;  //dynamically creating new node
            rear->next = temp;   //the next of rear is temp beacause rear is not equal to null
            temp->data = n1;    // the data in temp is n1
            temp->next = NULL;   //the next in temp is null i.e the linkedlist ends
            rear = temp;  //rear is equal to temp
        }
    }
    void Display() {
        temp = front;  //initalizing temp with front because we have to print the entire queue from begin to end
        if ((front == NULL) && (rear == NULL)) { //if front and rear are NULL then queue is empty.
            cout << "Queue is empty" << endl;
            return;
        }
        cout << "Queue elements are: ";
        while (temp != NULL) {           //Otherwise, all the queue elements are displayed using a while until temp is not equal to NULL.
            cout << temp->data << " ";  //printing data
            temp = temp->next;  //moving to next node
        }
        cout << endl;
    }
    void dequeue() {
        temp = front;
            if (front != NULL) {
                cout << "number deleted from queue is : ";
                if (temp->next != NULL) {
                    temp = temp->next;
                    cout << front->data << endl;
                    free(front);
                    front = temp;    //Otherwise, the element at front is deleted and front points to next element which is in temp.
                }
                else {
                    cout << front->data << endl;
                    free(front);
                    front = NULL;   //If there is only one element in the queue that is deleted and front and rear are set to NULL.
                    rear = NULL;
                }
            }
            else {  //if there are no elements in queue then it is underflow condition.
                cout << "the queue is empty" << endl;
                return;
            }
    }
};

int main() {
    node obj;  // class node object
    int choice;
    //user driven menu
    cout << "1- Insert element in queue" << endl;
    cout << "2- Delete element in queue" << endl;
    cout << "3- Display queue" << endl;
    cout << "4- Exit" << endl;
    do {
        cout << "Enter choice : " << endl;
        cin >> choice;
        switch (choice) {
        case 1:
            int n1;
            cout << "Insert data : " << endl;
            cin >> n1;
            obj.enqueue(n1);
            break;
        case 2: 
            obj.dequeue();
            break;
        case 3: 
            obj.Display();
            break;
        case 4: 
            cout << "Exit" << endl;
            break;
        default: 
            cout << "Invalid choice" << endl;
        }
    } while (choice != 4);
    return 0;
}