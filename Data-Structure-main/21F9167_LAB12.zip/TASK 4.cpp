#include <iostream>
using namespace std;
class AVLnode{
public:
	int data;
	AVLnode* left;
	AVLnode* right;
	AVLnode(){
		left = right = NULL;
	}
};
class AVL{
private:
	AVLnode* root;
	int* arr;
	int arr_size, arr_count, arr_rev;
	int count;
	void insert(int value, AVLnode*& Node){
		if (Node == NULL){
			Node = new AVLnode;
			Node->data = value;
			count++;
		}
		else if (value < Node->data){
			insert(value, Node->left);
		}
		else{
			insert(value, Node->right);
		}
		/*Node = Rotating(Node);*/
	}
	AVLnode* rrRotation(AVLnode*& Node){
		AVLnode* temp;
		temp = Node->right;
		Node->right = temp->left;
		temp->left = Node;
		return temp;
	}
	AVLnode* llRotation(AVLnode*& Node){
		AVLnode* temp;
		temp = Node->left;
		Node->left = temp->right;
		temp->right = Node;
		return temp;
	}
	AVLnode* rlRotation(AVLnode*& Node){
		AVLnode* temp;
		AVLnode* temp2;
		temp = Node->right;
		temp2 = Node->right->left;
		Node->right = temp2->left;
		temp->left = temp2->right;
		temp2->left = Node;
		temp2->right = temp;
		return temp2;
	}
	AVLnode* lrRotation(AVLnode*& Node){
		AVLnode* temp;
		AVLnode* temp2;
		temp = Node->left;
		temp2 = Node->left->right;
		Node->left = temp2->right;
		temp->right = temp2->left;
		temp2->right = Node;
		temp2->left = temp;
		return temp2;
	}
	AVLnode* Rotating(AVLnode* Node){
		if (balance(Node) == 2){
			if (balance(Node->left) == 1){
				Node = llRotation(Node);
				return Node;
			}
			else if (balance(Node->left) == -1){
				Node = lrRotation(Node);
				return Node;
			}
		}
		else if (balance(Node) == -2){
			if (balance(Node->right) == 1){
				Node = rlRotation(Node);
				return Node;
			}
			else if (balance(Node->right) == -1){
				Node = rrRotation(Node);
				return Node;
			}
		}
		return Node;
	}
public:
	AVL(int s){
		root = NULL;
		count = 0;
		arr_size = s;
		arr_count = 0;
		arr = new int[s];
	}
	bool isEmpty(){
		return(root == NULL);
	}
	void insertion(int value){
		insert(value, root);
	}
	int balance(AVLnode* Node){
		if (Node == NULL){
			return 0;
		}
		return (height(Node->left) - height(Node->right));
	}
	AVLnode* getRoot(){
		return root;
	}
	void inOrder_traversal(AVLnode* p){
		if (p != NULL){
			inOrder_traversal(p->left);
			arr[arr_count] = p->data;
			arr_count++;
			cout << p->data << " ";
			inOrder_traversal(p->right);
		}
	}
	void preOrder_traversal(AVLnode* p){
		if (p != NULL){
			p->data = arr[arr_rev];
			arr_rev++;
			preOrder_traversal(p->left);
			preOrder_traversal(p->right);
		}
	}
	int height(AVLnode* temp){
		if (temp == NULL){
			return -1;
		}
		int left = height(temp->left);
		int right = height(temp->right);
		if (left >= right){
			return left + 1;
		}
		else{
			return right + 1;
		}
	}
	void heap_display(AVLnode* p){
		if (p != NULL){
			heap_display(p->left);
			cout << p->data << " ";
			heap_display(p->right);
		}
	}
};
int main(){
	int size, value;
	cout << "Enter size : ";
	cin >> size;
	AVL obj(size);
	cout << "Insert value : " << endl;
	for (int i = 0; i < size; i++){
		cin >> value;
		obj.insertion(value);
	}
	cout << "BST : ";
	obj.inOrder_traversal(obj.getRoot());
	cout << endl;
	obj.preOrder_traversal(obj.getRoot());
	cout << "Minimum Heap : ";
	obj.heap_display(obj.getRoot());
	return 0;
}
