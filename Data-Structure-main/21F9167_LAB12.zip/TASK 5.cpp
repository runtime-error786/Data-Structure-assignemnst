#include<iostream>
using namespace std;
void swap(int* a, int* b){
    int temp = *a;
    *a = *b;
    *b = temp;
}
void max(int arr[], int i, int num){
    int left = 2 * i + 1;
    int right = 2 * i + 2;
    int largest = i;
    if (left < num && arr[left] > arr[i]) {
        largest = left;
    }
    if (right < num && arr[right] > arr[largest]) {
        largest = right;
    }
    if (largest != i) {
        swap(&arr[i], &arr[largest]);
        max(arr, largest, num);
    }
}
void display(int* arr, int size){
    for (int i = 0; i < size; ++i)
        cout<<arr[i]<<" ";
}
void conversion(int arr[], int N) {
    int i = (N - 2) / 2;
    while (i >= 0) {
        max(arr, i, N);
        --i;
    }
}
int main(){
    int arr[10];
    cout << "Enter Elements in array" << endl;
    for (int i = 0; i < 10; i++) {
        cin >> arr[i];
    }
    int size = sizeof(arr) / sizeof(arr[0]);
    cout << "Min Heap : ";
    display(arr, size);
    cout << endl;
    conversion(arr, size);
    cout << "Max Heap : ";
    display(arr, size);
}