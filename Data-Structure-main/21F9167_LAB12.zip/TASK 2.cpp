#include <iostream> 
using namespace std;
void func(int arr[], int size, int root){
    int largest = root;     int l = 2 * root + 1;     int r = 2 * root + 2;
    if (l < size && arr[l] > arr[largest]){
        largest = l;
    }
    if (r < size && arr[r] > arr[largest]){
        largest = r;
    }
    if (largest != root){
        swap(arr[root], arr[largest]);        
        func(arr, size, largest);
    }
}
void sorting(int arr[], int size){
    for (int i = size / 2 - 1; i >= 0; i--){
        func(arr, size, i);
    }
    for (int i = size - 1; i >= 0; i--){
        swap(arr[0], arr[i]);         
        func(arr, i, 0);
    }
}
void displayArray(int arr[], int size){
    for (int i = 0; i < size; ++i){
        cout << arr[i] << " ";
    }     cout << endl;
} 
int main(){
    int array[] = {22,19,20,10,8};
    int size = sizeof(array) / sizeof(array[0]);
    cout << "Array is :" << endl;
    displayArray(array, size);
    sorting(array, size);
    cout << "Sorted array is :" << endl;
    displayArray(array, size);
}
