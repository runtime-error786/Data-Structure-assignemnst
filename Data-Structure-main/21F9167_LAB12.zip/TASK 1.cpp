#include <iostream>
using namespace std;
class heap{
private:
	int* arr;
	int size, count;
	void mini_heapify_down(int root) {
		int smallest = root;
		int left = (root * 2) + 1;
		int right = (root * 2) + 2;
		if (left < count && arr[left] < arr[smallest]){
			smallest = left;
		}
		else if (right < count && arr[right] < arr[smallest]){
			smallest = right;
		}
		if (smallest != root){
			swap(arr[smallest], arr[root]);
			mini_heapify_down(smallest);
		}
	}
	void mini_heapify_up(int root) {
		int smallest = root;
		int parent = (root - 1) / 2;
		if (arr[parent] > arr[smallest]){
			smallest = parent;
		}
		if (smallest != root){
			swap(arr[root], arr[smallest]);
			mini_heapify_up(smallest);
		}
	}
public:
	heap(int s){
		size = s;
		arr = new int[size];
		count = 0;
	}
	bool isEmpty(){
		return (count == -1);
	}
	bool isFull(){
		return (count == size);
	}
	int getMini(){
		if (isEmpty()){
			return -1;
		}
		return arr[0];
	}
	int extractMin(){
		count--;
		swap(arr[0], arr[count]);
		mini_heapify_down(0);
		return arr[count];
	}
	void insert(int value){
		if (isFull()){
			cout << "Heap is Full" << endl;
		}
		else{
			count++;
			arr[count - 1] = value;
			mini_heapify_up(count - 1);
		}
	}
	void display(){
		for (int i = 0; i < count; i++){
			cout << arr[i] << " ";
		}
	}
};
int main(){
	int size, val;
	int choice;
	int n;
	cout << "Enter size: ";
	cin >> size;
	heap H(size);
	do {
		cout << "1- Insert" << endl;
		cout << "2- Display" << endl;
		cout << "3- Extraction" << endl;
		cout << "4- Get Minimum" << endl;
		cin >> choice;
		switch (choice) {
		case 1:
			cout << "Enter Values: " << endl;
			for (int i = 0; i < size; i++) {
				cin >> val;
				H.insert(val);
			}
			break;
		case 2:
			cout << endl << "\nHeap is : ";
			H.display();
			cout << endl;
			break;
		case 3:
			H.extractMin();
			cout << endl << "Heap after extraction : ";
			H.display();
			cout << endl;
			break;
		case 4:
			cout << endl << "Get Minimum : " << H.getMini() << endl;
			break;
		}
	} while (choice != 7);



}
